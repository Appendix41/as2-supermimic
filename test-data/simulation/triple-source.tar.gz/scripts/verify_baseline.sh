#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
baseline="$root/baseline"
if [[ $# -gt 1 || ( $# -eq 1 && $1 != --original ) ]]; then
  printf 'Usage: bash %s [--original]\n' "$0" >&2
  exit 2
fi

cd "$baseline/project"
sha256sum --check --strict --quiet "$baseline/project.SHA256SUMS"
cd "$baseline/evidence"
sha256sum --check --strict --quiet "$baseline/evidence.SHA256SUMS"
printf 'PASS: baseline source/assets and evidence match their SHA256 manifests.\n'

if [[ ${1:-} == --original ]]; then
  cd /home/jrz/Codex/supermimic
  sha256sum --check --strict --quiet "$baseline/project.SHA256SUMS"
  sha256sum --check --strict --quiet "$baseline/evidence.SHA256SUMS"
  sha256sum --check --strict --quiet "$baseline/training.SHA256SUMS"
  printf 'PASS: original source/assets, evidence and training files are unchanged.\n'
fi
