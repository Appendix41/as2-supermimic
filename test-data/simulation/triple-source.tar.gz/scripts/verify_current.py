"""Recheck isolation/integrity and record code/data/runtime identities locally."""

import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess

import torch

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/reference-selection"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=OUT)
    output = parser.parse_args().output.resolve()
    if not output.is_relative_to(ROOT / "outputs"):
        raise ValueError("audit output must remain under this subproject's outputs")
    output.mkdir(parents=True, exist_ok=True)
    runtime = {
        "packages": {p: importlib.metadata.version(p) for p in ("torch", "mujoco", "mjlab", "numpy")},
        "cuda_available": torch.cuda.is_available(),
        "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        "scope": "Post-implementation audit, not an exact experiment/replay snapshot.",
    }
    for name, command in (
        ("baseline", ["bash", "scripts/verify_baseline.sh"]),
        ("parent_comparison", ["bash", "scripts/verify_baseline.sh", "--original"]),
        ("paths", ["bash", "scripts/run.sh", "scripts/check_paths.py"]),
    ):
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        runtime[name] = {"returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    (output / "runtime-integrity.json").write_text(json.dumps(runtime, indent=2) + "\n")
    files = [
        p for folder in ("src/as2_motion_imitation", "scripts", "configs", "tests",
                         "data/processed", "data/raw/as2-native-crouch",
                         "data/raw/as2-native-forward-jump",
                         "data/raw/as2-native-triple-forward-jump")
        for p in (ROOT / folder).rglob("*")
        if p.is_file() and "__pycache__" not in str(p)
    ]
    files.extend(ROOT / name for name in ("README.md", "START_NEXT_CHAT.md", "IMPLEMENTATION_NOTES.md"))
    lines = [f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT)}" for p in sorted(files)]
    (output / "implementation.SHA256SUMS").write_text("\n".join(lines) + "\n")
    print(json.dumps(runtime, indent=2))


if __name__ == "__main__":
    main()
