#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
env_root=/home/jrz/apps/mujoco/envs/mjlab-cu130-py312

# Ignore inherited old-project paths; extension code gets a separate namespace.
export PYTHONPATH="$root/src:$root/baseline/project/src"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONNOUSERSITE=1
export PYTHONUNBUFFERED=1
export AS2_MOTION_ROOT="$root"
export AS2_OUTPUT_ROOT="$root/outputs"
export XDG_CACHE_HOME="$AS2_OUTPUT_ROOT/cache"
export WARP_CACHE_PATH="$XDG_CACHE_HOME/warp"
export CUDA_CACHE_PATH="$XDG_CACHE_HOME/cuda"
export TRITON_CACHE_DIR="$XDG_CACHE_HOME/triton"
export TORCHINDUCTOR_CACHE_DIR="$XDG_CACHE_HOME/torchinductor"
export TORCH_HOME="$XDG_CACHE_HOME/torch"
export HF_HOME="$XDG_CACHE_HOME/huggingface"
export PIP_CACHE_DIR="$XDG_CACHE_HOME/pip"
export MPLCONFIGDIR="$XDG_CACHE_HOME/matplotlib"
export TMPDIR="$AS2_OUTPUT_ROOT/tmp"
export WANDB_MODE=disabled
export WANDB_DIR="$AS2_OUTPUT_ROOT/wandb"
export WANDB_CACHE_DIR="$XDG_CACHE_HOME/wandb"
export WANDB_CONFIG_DIR="$XDG_CACHE_HOME/wandb-config"
export OMP_NUM_THREADS=2
export MKL_NUM_THREADS=2
export TORCHINDUCTOR_COMPILE_THREADS=2
export MUJOCO_GL="${MUJOCO_GL:-egl}"
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export PATH="/home/jrz/apps/mujoco/bin:$env_root/bin:$PATH"
mkdir -p "$XDG_CACHE_HOME" "$TMPDIR"
cd "$root"
exec "$env_root/bin/python" "$@"
