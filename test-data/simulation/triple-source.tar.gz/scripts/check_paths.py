"""Check handoff path isolation without starting simulation or training."""

import json
import os
from pathlib import Path
import sys
import tempfile

import as2_supermimic
from as2_supermimic.paths import OUTPUT_ROOT


def main():
  root = Path(__file__).resolve().parents[1]
  output = root / "outputs"
  baseline_src = root / "baseline/project/src"
  package = Path(as2_supermimic.__file__).resolve()
  expected_python = Path("/home/jrz/apps/mujoco/envs/mjlab-cu130-py312/bin/python")
  assert Path(sys.executable) == expected_python, sys.executable
  assert Path.cwd() == root, Path.cwd()
  assert package.is_relative_to(baseline_src), package
  assert OUTPUT_ROOT.resolve() == output, OUTPUT_ROOT
  assert str(root.parent / "src") not in sys.path, sys.path
  assert not (root / "src/as2_supermimic").exists(), "Do not shadow the baseline package"
  variables = (
    "AS2_OUTPUT_ROOT", "XDG_CACHE_HOME", "WARP_CACHE_PATH", "CUDA_CACHE_PATH",
    "TRITON_CACHE_DIR", "TORCHINDUCTOR_CACHE_DIR", "TORCH_HOME", "HF_HOME",
    "PIP_CACHE_DIR", "MPLCONFIGDIR", "TMPDIR", "WANDB_DIR", "WANDB_CACHE_DIR",
    "WANDB_CONFIG_DIR",
  )
  paths = {name: os.environ[name] for name in variables}
  for name, value in paths.items():
    assert Path(value).resolve().is_relative_to(output), (name, value)
  assert Path(tempfile.gettempdir()).resolve().is_relative_to(output)
  assert os.environ["WANDB_MODE"] == "disabled"
  print(json.dumps({
    "status": "passed", "python": sys.executable, "cwd": str(root),
    "baseline_import": str(package), "paths": paths,
    "simulation_started": False, "training_started": False,
  }, indent=2))


if __name__ == "__main__":
  main()
