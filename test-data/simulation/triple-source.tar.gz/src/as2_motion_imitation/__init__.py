"""AS2 reference tracking extensions to the frozen Go2-derived learner."""

SCHEMA_VERSION = "as2-motion-v1"
