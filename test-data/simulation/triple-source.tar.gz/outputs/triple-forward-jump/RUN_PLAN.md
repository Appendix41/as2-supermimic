# Three Consecutive Forward Jumps

Date: 2026-11-12. User requested a physically generated three-jump reference,
then training by the previously used method. All work is simulation-only.

## Fixed Protocol Before Collection

- Reuse the accepted single-jump PD parameters without changing the AS2 model,
  actuator gains, torque limits, or collision masks.
- One continuous CPU physics rollout, no resets, state concatenation, external
  impulses, or pose writes between jumps. Crouch onsets separated by 2.8 seconds.
- Duration 13.6 seconds, 50 Hz reference and recorded commands, 500 Hz audit.
- Acceptance: exactly three flights lasting at least 0.04 seconds; each must
  last at least 0.08 seconds and move forward at least 0.08 m while airborne.
  Require touchdown between jumps, final stable standing for at least 2 seconds,
  and the safety screens in configs/triple-forward-jump-acceptance.json.
- Test the script at seeds 100-119 with +/-0.01 rad initial offsets and 3-second
  ordinary physical settling. These are small perturbations, not robustness proof.

## Training And Evaluation

- Verify same-command CPU/MJWarp parity and tests before the full run.
- Train from scratch, 4096 MJWarp environments, seed 23, 1600 iterations,
  400 world-model warmup iterations and up to 1200 BPTT actor updates.
- Preserve replay, k=8 autoregressive world-model fitting, frozen-model BPTT,
  H=32 imagination, critic bootstrap and TD(lambda). No PPO or BC pretraining.
- Half the training environments use recorded commands with noise; the rest
  use the actor. Reference resets are training-only. Sampling and model response
  probes cover all three jumps.
- Save every 200 iterations; evaluate initial, intermediate, and final actors
  in separate CPU physics from ordinary standing, without a reference driver.
- Keep failures and source/checkpoint hashes. Success requires all three jumps
  in a single actor-controlled rollout, not three separate policy restarts.
- Retain all single-jump results. Shared GPU jobs are never modified.
